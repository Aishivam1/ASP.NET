using System.Web.Mvc;

namespace ASPNETApplication.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            ViewBag.Message = "Welcome to ASP.NET MVC 5!";
            ViewBag.CurrentDate = System.DateTime.Now.ToString("dddd, MMMM dd, yyyy");
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";
            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";
            return View();
        }
    }
}